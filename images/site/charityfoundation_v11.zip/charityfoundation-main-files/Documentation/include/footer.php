</div>
	<!--end page-->



	<!--main-->
	<script src="js/main/jquery.min.js"></script> <!--Jquery-->
	<script src="js/main/jquery-ui.min.js"></script> <!--Jquery UI-->
	<script src="js/plugins/scroolto/scroolto.js"></script> <!--Scrool To-->
	<script src="js/plugins/nicescrool/jquery.nicescroll.min.js"></script> <!--Nice Scroll-->

	<!--settings-->
	<script src="js/settings.js"></script> <!--settings-->



</body>  
</html>